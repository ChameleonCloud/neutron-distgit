Neutron Plugin Architecture
===========================

`Salvatore Orlando: How to write a Neutron Plugin (if you really need to) <http://www.slideshare.net/salv_orlando/how-to-write-a-neutron-plugin-if-you-really-need-to>`_

Plugin API
----------

.. automodule:: neutron.neutron_plugin_base_v2

.. autoclass:: NeutronPluginBaseV2
    :members:
